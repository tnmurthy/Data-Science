#install.packages("readxl")
#install.packages("ggplot2")
#install.packages("corrgram")


library(readxl)
library(ggplot2)          

Big_Mart_Dataset <- read_excel("D:/RStudio/R/Big Mart Dataset.xlsx")
View(Big_Mart_Dataset)

# ggplot2 is an R library for visualizations
# if we want to visualize the items as per their cost data, 
# then we can use scatter plot chart using two continuous variables, 
# namely Item_Visibility & Item_MRP as shown below

ggplot(Big_Mart_Dataset, aes(Item_Visibility, Item_MRP)) + 
  geom_point() + 
  scale_x_continuous("Item Visibility", breaks = seq(0,0.35,0.05)) + 
  scale_y_continuous("Item MRP", breaks = seq(0,270,by = 30)) + 
  theme_bw() 

# Now, we can view a third variable also in same chart, 
# say a categorical variable (Item_Type) which will give the characteristic 
# (item_type) of each data set. 
# Different categories are depicted by way of different color for item_type 
# in below chart

ggplot(Big_Mart_Dataset, aes(Item_Visibility, Item_MRP)) + 
  geom_point(aes(color = Item_Type)) + 
  scale_x_continuous("Item Visibility", breaks = seq(0,0.35,0.05)) +
  scale_y_continuous("Item MRP", breaks = seq(0,270,by = 30)) +
  theme_bw() + 
  labs(title="Scatterplot")

# We can even make it more visually clear by creating 
# separate scatter plots for separate category wise chart
# facet_wrap works superb & wraps Item_Type in rectangular layout

ggplot(Big_Mart_Dataset, aes(Item_Visibility, Item_MRP)) + 
  geom_point(aes(color = Item_Type)) + 
  scale_x_continuous("Item Visibility", breaks = seq(0,0.35,0.05)) +
  scale_y_continuous("Item MRP", breaks = seq(0,270,by = 30)) + 
  theme_bw() + 
  labs(title="Scatterplot") + 
  facet_wrap( ~ Item_Type)

# From our mart dataset, if we want to know the count of items on basis of their cost, 
# then we can plot histogram using continuous variable Item_MRP as shown below.

ggplot(Big_Mart_Dataset, aes(Item_MRP)) + 
  geom_histogram(binwidth = 2) +
  scale_x_continuous("Item MRP", breaks = seq(0,270,by = 30)) +
  scale_y_continuous("Count", breaks = seq(0,200,by = 20)) +
  labs(title = "Histogram")

# From our dataset, if we want to know number of marts established in particular year, 
# then bar chart would be most suitable option, use variable Establishment Year as shown below.

ggplot(Big_Mart_Dataset, aes(Outlet_Establishment_Year)) + 
  geom_bar(fill = "red") +
  theme_bw() +
  scale_x_continuous("Establishment Year", breaks = seq(1985,2010)) + 
  scale_y_continuous("Count", breaks = seq(0,1500,150)) +
  coord_flip() + 
  labs(title = "Bar Chart") + 
  theme_gray()

# To know item weights (continuous variable) on basis of Outlet Type (categorical variable) 
# on single bar chart

ggplot(Big_Mart_Dataset, aes(Item_Type, Item_Weight)) + 
  geom_bar(stat = "identity", fill = "darkblue") + 
  scale_x_discrete("Outlet Type") + 
  scale_y_continuous("Item Weight", breaks = seq(0,15000, by = 500)) + 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5)) + 
  labs(title = "Bar Chart")

# From our dataset, if we want to know the count of outlets on basis of 
# categorical variables like its type (Outlet Type) and location (Outlet Location Type) 
# both, stack chart will visualize the scenario in most useful manner

ggplot(Big_Mart_Dataset, aes(Outlet_Location_Type, fill = Outlet_Type)) + 
  geom_bar() +
  labs(title = "Stacked Bar Chart", x = "Outlet Location Type", y = "Count of Outlets")

# Box Plots are used to plot a combination of categorical and continuous variables 
# This plot is useful for visualizing the spread of the data and detect outliers
# It shows five statistically significant numbers- the minimum, the 25th percentile, 
# the median, the 75th percentile and the maximum along with outliers

ggplot(Big_Mart_Dataset, aes(Outlet_Identifier, Item_Outlet_Sales)) + 
  geom_boxplot(fill = "red") +
  scale_y_continuous("Item Outlet Sales", breaks= seq(0,15000, by=1000)) +
  labs(title = "Box Plot", x = "Outlet Identifier")

# Area chart is used to show continuity across a variable or data set 
# It is very much same as line chart and is commonly used for time series plots
# Alternatively, it is also used to plot continuous variables and analyze the 
# underlying trends. From our dataset, when we want to analyze the trend of item 
# outlet sales, area chart can be plotted as shown below 
# It shows count of outlets on basis of sales

ggplot(Big_Mart_Dataset, aes(Item_Outlet_Sales)) + 
  geom_area(stat = "bin", bins = 30, fill = "steelblue") + 
  scale_x_continuous(breaks = seq(0, 11000, 1500)) + 
  labs(title = "Area Chart", x = "Item Outlet Sales", y = "Count")

# Heat Map uses intensity (density) of colors to display relationship between 
# two or three or many variables in a two dimensional image
# It allows you to explore two dimensions as the axis and the third dimension 
# by intensity of color from our dataset, if we want to know cost of each item 
# on every outlet, we can plot heatmap as shown below using three variables Item MRP, 
# Outlet Identifier & Item Type from our mart dataset

ggplot(Big_Mart_Dataset, aes(Outlet_Identifier, Item_Type)) +
  geom_raster(aes(fill = Item_MRP)) +
  labs(title ="Heat Map", x = "Outlet Identifier", y = "Item Type") +
  scale_fill_continuous(name = "Item MRP")

# Correlogram is used to test the level of co-relation among the variable available 
# in the data set the cells of the matrix can be shaded or colored to show the 
# co-relation values from our dataset, let's check co-relation between Item cost, 
# weight, visibility along with Outlet establishment year and Outlet sales  
# from below plot

library(corrgram)

corrgram(Big_Mart_Dataset, order=NULL, panel=panel.shade, text.panel=panel.txt,
         main="Correlogram") 
