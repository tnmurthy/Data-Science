# Install
#install.packages("tm")  # for text mining
#install.packages("SnowballC") # for text stemming
#install.packages("wordcloud") # word-cloud generator 
#install.packages("RColorBrewer") # color palettes
# Load
library("tm")
library("SnowballC")
library("wordcloud")
library("RColorBrewer")

text <- readLines(file.choose())
docs <- Corpus(VectorSource(text))

#inspect(docs)

toSpace <- content_transformer(function (x , pattern ) gsub(pattern, " ", x))
docs <- tm_map(docs, toSpace, "/")
docs <- tm_map(docs, toSpace, "@")
docs <- tm_map(docs, toSpace, "\\|")

# Convert the text to lower case
docs <- tm_map(docs, content_transformer(tolower))
# Remove numbers
docs <- tm_map(docs, removeNumbers)
# Remove english common stopwords
docs <- tm_map(docs, removeWords, stopwords("english"))
# Remove your own stop word
# Remove punctuations
docs <- tm_map(docs, removePunctuation)
# Eliminate extra white spaces
docs <- tm_map(docs, stripWhitespace)


# specify your stopwords as a character vector
docs <- tm_map(docs, removeWords, c("tax","budget", "will","crore",
                                    "government","also","india","proposed","propose",
                                    "year","madam","speaker","per","act","lakh","need","economy",
                                    "therefore","committee","pradesh","provide",
                                    "crores","country","shall","case","like","well",
                                    "one")) 

dtm <- TermDocumentMatrix(docs)
m <- as.matrix(dtm)
v <- sort(rowSums(m),decreasing=TRUE)
d <- data.frame(word = names(v),freq=v)
head(d, 10)

set.seed(124)

options(warn=0)
wordcloud(words = d$word, freq = d$freq, min.freq = 1,
          max.words=100, random.order=FALSE, rot.per=0.35, 
          colors=brewer.pal(8, "Dark2"))
#title(x="India Union Budget 2015-16")
#wordcloud(docs, main="India Union Budget 2015-16")

findFreqTerms(dtm, lowfreq = 4)

#You can analyze the association between frequent terms (i.e., terms which correlate) using findAssocs() function
findAssocs(dtm, terms = "freedom", corlimit = 0.3)

library(ggplot)
ggplot(d[1:10,]$freq, las = 2, names.arg = d[1:10,]$word,
        col ="lightblue", main ="Most frequent words",
        ylab = "Word frequencies")